package com.capgemini.paymobbill.exception;								// NAME OF PACKAGE

public class InvalidNumberException extends Exception {           		// METHOD TO RAISE THE EXCEPTION OF INVALID NUMBER
	public InvalidNumberException() {
		System.out.println("You have entered an invalid number");   		// THROWS AN EXCEPTION

	}
}
