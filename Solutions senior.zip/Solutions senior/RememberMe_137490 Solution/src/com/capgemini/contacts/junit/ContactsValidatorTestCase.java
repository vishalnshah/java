package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.service.ContactsValidator;

public class ContactsValidatorTestCase {
	ContactsValidator valid = new ContactsValidator();
	@Test
	public void testValidateCName() {
		assertEquals(false,valid.validateCName("yup"));
	}

	@Test
	public void testValidateMobileNo() {
		assertEquals(false,valid.validateMobileNo("234156"));
	}

	@Test
	public void testValidateEmailID() {
		assertEquals(false,valid.validateEmailID("kumatan"));
	}

	@Test
	public void testValidateGroupName() {
		assertEquals(false,valid.validateGroupName("hello"));
	}

}
