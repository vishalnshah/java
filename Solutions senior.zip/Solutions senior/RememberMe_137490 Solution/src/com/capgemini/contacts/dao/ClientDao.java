package com.capgemini.contacts.dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.exception.ContactIdNotExist;
import com.capgemini.contacts.exception.DuplicateNameException;

public class ClientDao {
	static ArrayList list = new ArrayList();
	public void addToList (ContactDetails details)throws DuplicateNameException{
		boolean flag= false;
		Iterator it = list.iterator();
		while(it.hasNext()){
			ContactDetails cdetails=(ContactDetails) it.next();
			if(cdetails.getcName().equals(details.getcName())){
				flag=true;
				throw new DuplicateNameException();
			}
		}
		if(flag==false){
			
			try {
				list.add(details);
			} catch (Exception e) {
				
				System.out.println("Failed to add the contact");
			}
			System.out.println("Contact Added");
			System.out.println("Contact ID is: " + details.getContactID() );
		}
	
	}
	
	
	
	public void removeFromList(int contactID) throws ContactIdNotExist{
		Iterator it = list.iterator();
		boolean flag=false;
		int i=0;
		while(it.hasNext()){
			ContactDetails cdetails=(ContactDetails) it.next();
			if(cdetails.getContactID()==contactID){
				list.remove(cdetails);
				flag=true;
				System.out.println("Contact deleted successfully");
				break;
			}
			i++;
		}
		if(!flag){
			throw new ContactIdNotExist();
		}
		
	}
}
