package com.capgemini.contacts.ui;

import java.util.Scanner;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsHelper;
import com.capgemini.contacts.service.ContactsValidator;

public class ContactClient {
	static Scanner obj = new Scanner(System.in);
	public static void main(String[] args) {
		
		ContactClient obj1 = new ContactClient();
		obj1.displayMenu();
	}
	public void displayMenu(){
		int choice;
		boolean validate=false;
		ContactsValidator valid = new ContactsValidator(); 
		ContactDetails cd = new ContactDetails();
		ContactsHelper help = new ContactsHelper();
	
	
		while(true){
		System.out.println("Please enter your choice :");
		System.out.println("1. Add New Contact");
		System.out.println("2. Delete Contact");
		System.out.println("3. Exit");
		
		try {
			choice=Integer.parseInt(obj.nextLine());
		
		
		switch(choice){
		case 1:
			do{
				System.out.println("Enter Details:");
				cd= takeUserInput();
				validate=valid.validateDetails(cd);
				if(!validate){
					System.out.println("Please Enter the correct Details");
				}
			}
			while(validate==false);
			help.addContactDetails(cd);
			
			break;
		case 2:
			System.out.println("Enter the contact ID: ");
			int contactID = Integer.parseInt(obj.nextLine());
			help.deleteContactDetails(contactID);
			break;
		case 3:
			System.exit(0);
			
		default: 
			System.out.println("You have entered wrong choice");
		
		}
		} catch (NumberFormatException e) {
			
			System.out.println("Please enter valid choice");
		}
		}
	}
	
	public static ContactDetails takeUserInput(){
		ContactDetails obj2 = new ContactDetails();
	
		System.out.print("Enter Name : ");
		obj2.setcName(obj.nextLine());
		System.out.print("Enter Mobile No. : ");
		obj2.setMobileNo1(obj.nextLine());
		System.out.print("Do you want to add alternate Mobile No. ? ");
		
		char ch;
		ch = obj.nextLine().charAt(0);
		if(ch=='Y' || ch=='y')
		{
			System.out.print("Enter Mobile No. : ");
			obj2.setMobileNo2(obj.nextLine());
		}
		else{
			obj2.setMobileNo2(null);
		}
		System.out.print("Enter Email Id : ");
		obj2.setEmailID(obj.nextLine());
		
		System.out.print("Select the Group (Friends/Family/CoWorkers) : ");
		String group=obj.nextLine().toUpperCase();
		obj2.setGroupName(group);
		
		return obj2;
	}
}
