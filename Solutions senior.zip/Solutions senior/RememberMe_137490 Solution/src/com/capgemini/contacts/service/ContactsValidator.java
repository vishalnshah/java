package com.capgemini.contacts.service;

import java.util.Random;

import com.capgemini.contacts.bean.ContactDetails;

public class ContactsValidator {
	public boolean validateCName(String cName){
		return cName.matches("[a-zA-Z\\s]{5,15}");
	}
	public boolean validateMobileNo(String mobileNo){
		return mobileNo.matches("[7-9][0-9]{9}");
		
	}
	public boolean validateGroupName(String groupName){
		return groupName.matches("FRIENDS|FAMILY|COWORKERS");
	}
	public boolean validateEmailID(String emailID){
		return emailID.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");
	}
	
	public boolean validateDetails(ContactDetails details) {
		
		try {
			ContactsValidator cv = new ContactsValidator();
			if (cv.validateCName(details.getcName())&&cv.validateMobileNo(details.getMobileNo1())&&cv.validateEmailID(details.getEmailID())&&cv.validateGroupName(details.getGroupName())){
				 if(details.getMobileNo2()==null||cv.validateMobileNo(details.getMobileNo2()))
				 {	Random ran = new Random();
				 	details.setContactID(ran.nextInt(10));
				 	return true;
				 }
				 else{
					 return false;
				 }
			}
			else{
				return false;
			}
		} catch (Exception e) {
			System.out.println("Failed to add the Contact.");
			return false;
		}
		
		
	}
}
