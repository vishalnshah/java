package com.capgemini.paymobbill.junit;       								// NAME OF THE PACKAGE	

import static org.junit.Assert.*;
import org.junit.Test;														// NECESSARY IMPORTS
import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {									// CLASS RECHARGEFILEHELPERTESTCASE
	
	RechargeFileHelper RfH = new RechargeFileHelper();						// CREATING THE OBJECT OF THE CLASS
	
	RechargeDetails tdata1= new RechargeDetails("prepaid","jio","7985019957",309,1234); 		// ASSIGNING THE VALUES 

	@Test
	
	(timeout=50)
	public void testFileWrite() {											// TEST CASES FOR WRITING ONTO THE FILE
		RfH.fileWrite(tdata1);
		
	}

	@Test
	
	(timeout=200)														// TEST CASE FOR READING FROM THE FILE 
	public void testReadFile() {
		RfH.readFile();
	}

}
