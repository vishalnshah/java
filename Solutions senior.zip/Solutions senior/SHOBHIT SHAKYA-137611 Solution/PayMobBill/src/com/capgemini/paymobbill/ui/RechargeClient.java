package com.capgemini.paymobbill.ui;                           		   // PACKAGE NAME

import java.security.Provider.Service;                        
import java.util.Scanner;
import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;      // NECESSARY IMPORTS 
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {                                          // CLASS RECHARGECLIENT
	Scanner scanner = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();                          
	RechargeDataValidator RdV=new RechargeDataValidator();            // CREATING THE DIFFERENT OBJECTS OF VARIOUS CLASSES 
	RechargeFileHelper RfH = new RechargeFileHelper();                      
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {                                                         // EXCEPTION HANDLING
			rc.displayMenu();                                 
		} catch (InvalidNumberException e) {
			
			
		}
	}
	public void displayMenu() throws InvalidNumberException                   // METHOD TO CREATE THE MAIN MENU 
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option;
		try{                                                        // EXCEPTION HANDLING
			option=Integer.parseInt(scanner.nextLine());
		}catch(NumberFormatException nfe){
			throw new InvalidNumberException();
		}
		switch(option)                                            // SWITCH AND ITS CASES TO DISPLAY THE MENU AND HANDLING EXCEPTIONS
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			details();
			displayMenu();
			break;
		case 3:
			System.out.println("You Have Successfully Closed The Application");
			System.exit(0);
			break;
		default:
			throw new InvalidNumberException();
			
		}
	}
	private void details()											// METHOD TO READ THE FILE  
	{
		RfH.readFile();												// ACCESSING THE FILE USING THE OBJECT
		
	}
	private void recharge() 										// METHOD TO ENTER THE DEATILS OF THE RECHARGE
	{
			
			System.out.println("Select Recharge Type (Prepaid/Postpaid)");
			String type=scanner.nextLine();
			obj.setRechargeType(type);
			System.out.println("Enter Mobile No.");
			String mobileNo=scanner.nextLine();
			obj.setMobileNo(mobileNo);														// DIFFERENT DETAILS OF RECHARGE
			System.out.println("Select Current Operator (Airtel/Docomo/BSNL/Jio)");
			String currentOperator=scanner.nextLine();
			obj.setCurrentOperator(currentOperator);
			System.out.println("Enter Amount (Rs)");
			double amount=Math.round(Double.parseDouble(scanner.nextLine()) * 100D) / 100D;
			obj.setAmount(amount);
			
			if(RdV.validateDetails(obj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransactionID());		// CONFIRMATION OF RECHARGE
				RfH.fileWrite(obj);
			}
			else
			{
				System.out.println("Failed to recharge.");												// DECLINATION OF RECHARGE 
			}
	
		
		
	}

}
