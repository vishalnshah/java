package com.capgemini.paymobbill.service;							// NAME OF THE PACKAGE

import com.capgemini.paymobbill.bean.RechargeDetails;				// NECESSARY IMPORTS	

public class RechargeDataValidator {								// CLASS RECHARGEDATAVALIDATOR

	public boolean validateDetails(RechargeDetails PrU)				// METHOD TO VALIDATE THE DATA ENTERED BY THE USER AT RUNTIME
	{
		if(validateRechargeType(PrU) && validateMobileNo(PrU) && validateCurrentOperator(PrU) && validateAmount(PrU) && validateTransactionID(PrU))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	private boolean validateTransactionID(RechargeDetails PrU) 		// METHOD TO VALIDATE THE TRANSACTION ID 
	{
		String transactionID= Integer.toString(PrU.getTransactionID()); 		
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
		
	}
	private boolean validateAmount(RechargeDetails PrU)				// METHOD TO VALIDATE THE AMOUNT ENETERED BY THE USER
	{
		double amount=PrU.getAmount();
		try {
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException NfE) {							// EXCEPTION HANDLING
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	private boolean validateCurrentOperator(RechargeDetails PrU)	// METHOD TO VALIDATE THE CURRENT OPERATOR ENTERED BY THE USER
	{
		String x = PrU.getCurrentOperator().toLowerCase();
		String y = PrU.getCurrentOperator().toLowerCase();			// ACCEPTING THE CURRENT OPERATOR IN LOWER CASES
		String z = PrU.getCurrentOperator().toLowerCase();
		String a = PrU.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	private boolean validateMobileNo(RechargeDetails PrU) 			// METHOD TO VALIDATE THE MOBILE NUMBER
	{
		String MobileNo=PrU.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateRechargeType(RechargeDetails PrU)		// METHOD TO VALIDATE THE RECHARGE TYPE 
	{
		if(PrU.getRechargeType().toLowerCase().equals("prepaid") || PrU.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}

}
